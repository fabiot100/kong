/**
 * Created by user on 24/05/2017.
 */

module.exports.paths = {
    "uploads" : ( process.env.STORAGE_PATH || './kongadata/' )+ 'uploads/'
};
