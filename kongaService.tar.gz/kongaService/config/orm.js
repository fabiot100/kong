module.exports.orm = {
    _hookTimeout: 60000 // I used 60 seconds as my new timeout
};